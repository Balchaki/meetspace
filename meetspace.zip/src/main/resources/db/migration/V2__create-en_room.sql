CREATE TABLE en_room (
                         seq_room SERIAL PRIMARY KEY,
                         name VARCHAR(50) NOT NULL,
                         capacity INTEGER NOT NULL
);
