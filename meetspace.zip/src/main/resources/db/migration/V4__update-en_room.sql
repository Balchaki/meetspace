ALTER TABLE en_room ADD enabled bool NULL;
