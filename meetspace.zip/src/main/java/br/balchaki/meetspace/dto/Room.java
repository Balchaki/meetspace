package br.balchaki.meetspace.dto;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Room {
    private Long roomId;
    private String name;
    private Integer capacity;
    private Boolean enabled;
}
