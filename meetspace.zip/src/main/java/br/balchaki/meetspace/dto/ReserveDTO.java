package br.balchaki.meetspace.dto;

import br.balchaki.meetspace.domain.Room.Room;

import java.util.List;

public class ReserveDTO {
    List<Room> rooms = null;
}
