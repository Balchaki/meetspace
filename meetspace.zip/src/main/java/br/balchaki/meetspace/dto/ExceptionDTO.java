package br.balchaki.meetspace.dto;

public class ExceptionDTO {
}
