package br.balchaki.meetspace.service;

public class ReserveService {
}
