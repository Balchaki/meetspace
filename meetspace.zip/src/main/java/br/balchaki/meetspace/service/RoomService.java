package br.balchaki.meetspace.service;

import br.balchaki.meetspace.domain.Room.Room;
import br.balchaki.meetspace.domain.Room.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomService {
    @Autowired
    private final RoomRepository roomRepository;

    public RoomService(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    public List<Room> getAllEnabled() {
        return roomRepository.findByEnabled(true);
    }

    public Boolean createRoom(Room room) {
        try {
            roomRepository.save(room);
            return true;
        } catch (Exception e) {
            // Log the exception
            System.err.println("Error creating room: "+ e);
            return false;
        }
    }

    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }
}
