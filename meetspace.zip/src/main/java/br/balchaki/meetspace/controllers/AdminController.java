package br.balchaki.meetspace.controllers;

public class AdminController {
}
