package br.balchaki.meetspace.controllers;

import br.balchaki.meetspace.domain.Room.Room;
import br.balchaki.meetspace.domain.User.User;
import br.balchaki.meetspace.dto.RegisterRoomRequestDTO;
import br.balchaki.meetspace.dto.RegisterRoomResponseDTO;
import br.balchaki.meetspace.dto.RoomDTO;
import br.balchaki.meetspace.dto.UserResponseDTO;
import br.balchaki.meetspace.security.JwtUtil;
import br.balchaki.meetspace.service.RoomService;
import br.balchaki.meetspace.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rooms/")
public class RoomController {
    @Autowired
    private final JwtUtil jwtUtil;
    @Autowired
    private final UserService userService;
    @Autowired
    private final RoomService roomService;

    public RoomController(JwtUtil jwtUtil, UserService userService, RoomService roomService) {
        this.jwtUtil = jwtUtil;
        this.userService = userService;
        this.roomService = roomService;
    }


    @GetMapping("/enabled")
    public ResponseEntity<?> getAllEnabled(@RequestHeader("Authorization") String token) throws Exception {
        try{
            String jwt = token.substring(7);
            if(userService.isTokenInvalid(jwt)){
                return ResponseEntity.status(401).body("Invalid token");
            }
            String email = jwtUtil.extractUsername(jwt);
            User user = userService.findByEmail(email);
            if(user.getIsAdmin()){
                return ResponseEntity.ok().body(new RoomDTO(roomService.getAllRooms()));
            } else {
                return ResponseEntity.ok().body(new RoomDTO(roomService.getAllEnabled()));
            }
        } catch (Exception e) {
            throw new Exception("Error getting user data", e);
        }
    }

    @PostMapping("/create")
    public ResponseEntity<?> createRoom(@RequestHeader("Authorization") String token, @RequestBody RegisterRoomRequestDTO roomDTO) throws Exception {
        try{
            String jwt = token.substring(7);
            if(userService.isTokenInvalid(jwt)){
                return ResponseEntity.status(401).body("Invalid token");
            }
            String email = jwtUtil.extractUsername(jwt);
            User user = userService.findByEmail(email);
            if(user.getIsAdmin()){
                Room room = new Room();
                room.setName(roomDTO.getName());
                room.setEnabled(true);
                room.setCapacity(roomDTO.getCapacity());
                Boolean success = roomService.createRoom(room);
                if(success){
                    return ResponseEntity.ok().body(new RegisterRoomResponseDTO(success));
                }else {
                    return ResponseEntity.status(403).body(new RegisterRoomResponseDTO(success));
                }
            } else {
                return ResponseEntity.status(403).body(new RegisterRoomResponseDTO(false));
            }
        } catch (Exception e) {
            throw new Exception("Error creating room", e);
        }
    }
}
